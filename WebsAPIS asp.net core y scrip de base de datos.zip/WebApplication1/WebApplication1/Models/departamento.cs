﻿namespace WebApplication1.Models
{
    public class departamento
    {


        public int id { get; set; }
        public string Nombre { get; set; }
    }
}
