﻿namespace WebApplication1.Models
{
    public class Personal
    {


        public int id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Fecha_de_nacimiento { get; set; }
        public string Lugar_de_nacimiento { get; set; }
        public string Fecha_de_alta_de_registro { get; set; }
        public string id_Departamento { get; set; }
    }
}
