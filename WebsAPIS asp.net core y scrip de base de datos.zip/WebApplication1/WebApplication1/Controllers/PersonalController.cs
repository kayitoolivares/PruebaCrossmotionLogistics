﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//using System.Data;
//using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PersonalController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public PersonalController(IConfiguration configuration)
        {
            _configuration = configuration;
        }


        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
                         
            exec spCrudPersonal 'R',null,null,null,null,null,null,null
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmpleadosConexion");
            SqlDataReader myDataReader;
            using (SqlConnection myConnection = new SqlConnection(sqlDataSource))
            {
                myConnection.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConnection))
                {
                    myDataReader = myCommand.ExecuteReader();
                    table.Load(myDataReader);
                    myDataReader.Close();
                    myConnection.Close();
                }
            }
            return new JsonResult(table);

        }



        [HttpPost]
        public JsonResult Post(Personal dp)
        {
            string query = @"
                           
    exec spCrudPersonal 'C',null,@Nombre,@Apellido,@Fecha_de_nacimiento,@Lugar_de_nacimiento,null,@id_Departamento
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmpleadosConexion");
            SqlDataReader myDataReader;
            using (SqlConnection myConnection = new SqlConnection(sqlDataSource))
            {
                myConnection.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConnection))
                {
                    myCommand.Parameters.AddWithValue("@Nombre", dp.Nombre);
                    myCommand.Parameters.AddWithValue("@Apellido", dp.Apellido);
                    myCommand.Parameters.AddWithValue("@Fecha_de_nacimiento", dp.Fecha_de_nacimiento);
                    myCommand.Parameters.AddWithValue("@Lugar_de_nacimiento", dp.Lugar_de_nacimiento);
                    myCommand.Parameters.AddWithValue("@id_Departamento", dp.id_Departamento);
                    myDataReader = myCommand.ExecuteReader();
                    table.Load(myDataReader);
                    myDataReader.Close();
                    myConnection.Close();
                }
            }
            return new JsonResult("insert correctamente");

        }

        [HttpPut]
        public JsonResult Put(Personal dp)
        {
            string query = @"
                           
                exec spCrudPersonal 'U',@id,@Nombre,@Apellido,@Fecha_de_nacimiento,@Lugar_de_nacimiento,null,@id_Departamento
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmpleadosConexion");
            SqlDataReader myDataReader;
            using (SqlConnection myConnection = new SqlConnection(sqlDataSource))
            {
                myConnection.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConnection))
                {
                    myCommand.Parameters.AddWithValue("@id", dp.id);
                    myCommand.Parameters.AddWithValue("@Nombre", dp.Nombre);
                    myCommand.Parameters.AddWithValue("@Apellido", dp.Apellido);
                    myCommand.Parameters.AddWithValue("@Fecha_de_nacimiento", dp.Fecha_de_nacimiento);
                    myCommand.Parameters.AddWithValue("@Lugar_de_nacimiento", dp.Lugar_de_nacimiento);
                    myCommand.Parameters.AddWithValue("@id_Departamento", dp.id_Departamento);
                    myDataReader = myCommand.ExecuteReader();
                    table.Load(myDataReader);
                    myDataReader.Close();
                    myConnection.Close();
                }
            }
            return new JsonResult("update correctamente");

        }

        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"
                         
exec spCrudPersonal 'D',@id,null,null,null,null,null,null
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmpleadosConexion");
            SqlDataReader myDataReader;
            using (SqlConnection myConnection = new SqlConnection(sqlDataSource))
            {
                myConnection.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConnection))
                {
                    //myCommand.Parameters.AddWithValue("@nombreDepartamento", dp.Nombre);
                    myCommand.Parameters.AddWithValue("@id", id);
                    myDataReader = myCommand.ExecuteReader();
                    table.Load(myDataReader);
                    myDataReader.Close();
                    myConnection.Close();
                }
            }
            return new JsonResult("delet correctamente");

        }


    }
}
