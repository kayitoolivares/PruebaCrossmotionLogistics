﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
//using System.Data;
//using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Data.SqlClient;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartamentoController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        public DepartamentoController(IConfiguration configuration)
        {
            _configuration= configuration;
        }

        [HttpGet]
        public JsonResult Get()
        {
            string query = @"
                            Select * from dbo.departamento
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmpleadosConexion");
            SqlDataReader myDataReader;
            using(SqlConnection myConnection = new SqlConnection(sqlDataSource))
            {
                myConnection.Open();
                using(SqlCommand myCommand =new  SqlCommand(query, myConnection))
                {
                    myDataReader = myCommand.ExecuteReader();
                    table.Load(myDataReader);
                    myDataReader.Close();
                    myConnection.Close();
                }
            }
            return new JsonResult(table);

        }



        [HttpPost]
        public JsonResult Post(departamento dp)
        {
            string query = @"
                            insert into departamento values (@nombreDepartamento)
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmpleadosConexion");
            SqlDataReader myDataReader;
            using (SqlConnection myConnection = new SqlConnection(sqlDataSource))
            {
                myConnection.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConnection))
                {
                    myCommand.Parameters.AddWithValue("@nombreDepartamento", dp.Nombre);
                    myDataReader = myCommand.ExecuteReader();
                    table.Load(myDataReader);
                    myDataReader.Close();
                    myConnection.Close();
                }
            }
            return new JsonResult("insert correctamente");

        }

        [HttpPut]
        public JsonResult Put(departamento dp)
        {
            string query = @"
                            update departamento set Nombre= @nombreDepartamento where id=@id
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmpleadosConexion");
            SqlDataReader myDataReader;
            using (SqlConnection myConnection = new SqlConnection(sqlDataSource))
            {
                myConnection.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConnection))
                {
                    myCommand.Parameters.AddWithValue("@nombreDepartamento", dp.Nombre);
                    myCommand.Parameters.AddWithValue("@id", dp.id);
                    myDataReader = myCommand.ExecuteReader();
                    table.Load(myDataReader);
                    myDataReader.Close();
                    myConnection.Close();
                }
            }
            return new JsonResult("update correctamente");

        }

        [HttpDelete("{id}")]
        public JsonResult Delete(int id)
        {
            string query = @"
                            delete departamento  where id=@id
                            ";
            DataTable table = new DataTable();
            string sqlDataSource = _configuration.GetConnectionString("EmpleadosConexion");
            SqlDataReader myDataReader;
            using (SqlConnection myConnection = new SqlConnection(sqlDataSource))
            {
                myConnection.Open();
                using (SqlCommand myCommand = new SqlCommand(query, myConnection))
                {
                    //myCommand.Parameters.AddWithValue("@nombreDepartamento", dp.Nombre);
                    myCommand.Parameters.AddWithValue("@id", id);
                    myDataReader = myCommand.ExecuteReader();
                    table.Load(myDataReader);
                    myDataReader.Close();
                    myConnection.Close();
                }
            }
            return new JsonResult("delet correctamente");

        }

    }
}
