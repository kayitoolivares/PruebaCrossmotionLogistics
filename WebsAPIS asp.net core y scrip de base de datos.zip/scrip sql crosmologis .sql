


create database pruebaCrossmotion;
go;

use pruebaCrossmotion;
go:


create table personal(
    @id, integer identity(1,1) primary key,
    @Nombre, varchar(100),
    @Apellido, varchar(100),    
    @Fecha_de_nacimiento, date,
    @Lugar_de_nacimiento, varchar(100),
    @Fecha_de_alta_de_registro, date,
    @id_Departamento, integer
)

create table departamento(    
    id integer identity(1,1) primary key,
    Nombre varchar(100)
)


insert into departamento values('TI')
insert into departamento values('RH')
insert into departamento values('Marqueting')
insert into departamento values('Ventas ')


--store Procedure CRUD de personal select con joins
create procedure spCrudPersonal
@tipo char,
@id integer ,@Nombre varchar(100),@Apellido varchar(100),   @Fecha_de_nacimiento date,@Lugar_de_nacimiento varchar(100),
@Fecha_de_alta_de_registro date,@id_Departamento integer
as
begin

declare @respuesta varchar(50);
if	@tipo='C'
begin
insert into  personal values (@Nombre,@Apellido,@Fecha_de_nacimiento ,@Lugar_de_nacimiento,getdate(),@id_Departamento)
end
if	@tipo='R'
begin

select p.id,p.nombre,p.Apellido, convert(varchar(10),p.Fecha_de_nacimiento) as Fecha_de_nacimiento,p.Lugar_de_nacimiento,

convert(varchar(10),p.Fecha_de_alta_de_registro) as Fecha_de_alta_de_registro,p.id_Departamento  , d.nombre as nombre_Departamento
from personal p left  join departamento d
on d.id=p.id_Departamento


end
if	@tipo='U'
begin
	update personal set 
                                Nombre=@Nombre,
                                Apellido=@Apellido,
                                Fecha_de_nacimiento=@Fecha_de_nacimiento,
                                Lugar_de_nacimiento=@Lugar_de_nacimiento,
                                id_Departamento=@id_Departamento

                            where id=@id

end
if	@tipo='D'
begin
	delete personal  where id=@id

end


end